
#include "protocol.hpp"

int serve_on_tcp(unsigned int port);
